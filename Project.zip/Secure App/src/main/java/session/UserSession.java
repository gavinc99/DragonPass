package session;

import java.util.HashSet;
import java.util.Set;

public final class UserSession {

    public static UserSession instance;
    public static String userName;



    public UserSession(String userName) {
        UserSession.userName = userName;

    }

    public static UserSession getInstace(String userName) {
        if(instance == null) {
            instance = new UserSession(userName);
        }
        return instance;
    }

    public String getUserName() {
        return userName;
    }

    public static void cleanUserSession() {
        userName = "";// or null
    }

    @Override
    public String toString() {
        return "UserSession{" +
                "userName='" + userName +
                '}';
    }
}