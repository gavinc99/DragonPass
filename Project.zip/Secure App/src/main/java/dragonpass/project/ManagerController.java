package dragonpass.project;

import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;
import session.UserSession;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Logger;
import model.PasswordManager;
import monitor.FileObserver;
import monitor.Observer;
import monitor.SQLiteObserver;
import monitor.Subject;

import java.io.IOException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javax.swing.*;
import javax.swing.JPasswordField;
import javafx.scene.control.ContentDisplay;

public class ManagerController implements Initializable {

    @FXML
    private Button backB;

    @FXML
    private TableView<PasswordManager> tableManager;

    @FXML
    private TableColumn<PasswordManager, String> col_app;

    @FXML
    private TableColumn<PasswordManager, String> col_username;

    @FXML
    private TableColumn<PasswordManager, String> col_password;


    @FXML
    private Button addTable;

    @FXML
    private Button refreshTable;

    @FXML
    private ImageView eye;

    @FXML
    private ImageView bin;





    Subject monitor = new Subject();
    Observer observe1 = new SQLiteObserver(monitor);
    Observer observe2 = new FileObserver(monitor);


    Connection conn;
    ResultSet rs;


    ObservableList<PasswordManager> PasswordList = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        loadData();

    }


    //loads data for password manager table
    private void loadData() {

        col_app.setCellValueFactory(new PropertyValueFactory<>("app"));
        col_username.setCellValueFactory(new PropertyValueFactory<>("username"));
        col_password.setCellValueFactory(new PropertyValueFactory<>("password"));

        try {
            PasswordList.clear();
            String query = "SELECT * FROM " + UserSession.instance.getUserName();

            DatabaseConnection connect = new DatabaseConnection();
            conn = connect.getVerification();
            PreparedStatement stmt = conn.prepareStatement(query);

            rs = stmt.executeQuery();


            while (rs.next()) {
                PasswordList.add(new PasswordManager(
                        rs.getString("app"),
                        rs.getString("username"),
                        rs.getString("password")));
                tableManager.setItems(PasswordList);

            }
        }
        catch(Exception e){
            monitor.setLog(new Logger("warn", e.getMessage()));
        }

    }


    public void refreshTableAction(){

        try {
            PasswordList.clear();
            String query = "SELECT * FROM " + UserSession.instance.getUserName();

            DatabaseConnection connect = new DatabaseConnection();
            conn = connect.getVerification();
            PreparedStatement stmt = conn.prepareStatement(query);

            rs = stmt.executeQuery();


            while (rs.next()) {
                PasswordList.add(new PasswordManager(
                        rs.getString("app"),
                        rs.getString("username"),
                        rs.getString("password")));
                tableManager.setItems(PasswordList);

            }
        }
        catch(Exception e){
            monitor.setLog(new Logger("warn", e.getMessage()));
        }

    }

    public void addTableAction() throws IOException {

        //Close stage
        Stage stage = (Stage) addTable.getScene().getWindow();
        stage.close();

        //Loads FXML for add column manager
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("addManager.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 482, 441);
        stage.setTitle("Dragon Pass");
        stage.setScene(scene);
        stage.show();
        monitor.setLog(new Logger("info", "MenuController Accessed"));

    }

    


    //Exit button action
    public void backBAction() throws IOException {

        //Close stage
        Stage stage = (Stage) backB.getScene().getWindow();
        stage.close();

        //Loads FXML for menu
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 500);
        stage.setTitle("Dragon Pass");
        stage.setScene(scene);
        stage.show();
        monitor.setLog(new Logger("info", "MenuController Accessed"));

    }


    public void binIcon(javafx.scene.input.MouseEvent mouseEvent) {

        try {

            String query = "DELETE FROM " + UserSession.instance.getUserName() + "WHERE =" + PasswordList;

            DatabaseConnection connect = new DatabaseConnection();
            conn = connect.getVerification();
            PreparedStatement stmt = conn.prepareStatement(query);

            stmt.executeQuery();


        } catch (Exception e) {

        }

    }

    public void eyeIcon(MouseEvent mouseEvent) {
    }

    public void deleteTableAction(ActionEvent event) {
    }
}
