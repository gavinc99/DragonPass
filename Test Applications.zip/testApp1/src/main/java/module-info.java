module com.example.endTest {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.java;


    opens endTest to javafx.fxml;

    exports endTest;
}