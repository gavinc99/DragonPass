package endTest;

public class Success {
}
