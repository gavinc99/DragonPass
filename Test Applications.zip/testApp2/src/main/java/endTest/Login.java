package endTest;

import Crypto.Hash;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {

    @FXML
    private Button exitB;

    @FXML
    private Label invalidLabel;

    @FXML
    private Button loginBtn;

    @FXML
    private Label passLabel;

    @FXML
    private PasswordField passTF;

    @FXML
    private TextField usernameTF;

    @FXML
    private TextField dragonUserTF;

    @FXML
    void exitBAction(ActionEvent event) {

        Stage stage = (Stage) exitB.getScene().getWindow();
        stage.close();

    }

    @FXML
    void loginBtnAction(ActionEvent event) throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {


            Connection conn = null;
            PreparedStatement stmt = null;
            ResultSet rs;

            //setting user input to username
            String user = dragonUserTF.getText();

            String username = usernameTF.getText();

            String password = passTF.getText();

            String pass = Hash.toHexString(Hash.getSHA(password));

            String query = "select * from " + user + " WHERE app = 'testApp2' and username = ? and passHashed = ?";

            //connecting to database
            DatabaseConnection connect = new DatabaseConnection();
            conn = connect.getVerification();
            stmt = conn.prepareStatement(query);

            //Parameters for query
            stmt.setString(1, username);
            stmt.setString(2, pass);


            //Executing prepared statement
            rs = stmt.executeQuery();

            //Query was successful continue
            if (rs.next()) {

                //Close stage
                Stage stage = (Stage) exitB.getScene().getWindow();
                stage.close();

                //Loads FXML for menu
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("success.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 800, 500);
                stage.setTitle("endTest");
                stage.setScene(scene);
                stage.show();


            } else {
                invalidLabel.setText("Incorrect Details!");
            }
        }


}
